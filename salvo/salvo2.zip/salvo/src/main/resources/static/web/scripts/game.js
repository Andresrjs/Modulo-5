$(function() {
    loadData();
});

 var urlParams = new URLSearchParams(window.location.search);
  var gamePlayerId = urlParams.get('Gp');

 const createGrid = (size, gridId, gridType) => {

    let gridContainer = document.querySelector('.' + gridId);

    for (let i = 0; i < size; i++) {
      let row = document.createElement('div');

      let rowId = String.fromCharCode(i + 64).toLowerCase();

      gridContainer.appendChild(row);

      for (let j = 0; j < size; j++) {
        // Creates a div (cell) for each row.
        let cell = document.createElement('div');
        cell.classList.add('grid-cell');
        if (i > 0 && j > 0) {
          //example: id="salvog5" / id="shipc3"
          cell.id = gridType + rowId + j;
        }
        if (j === 0 && i > 0) {
          // Adds header's column name.
          cell.classList.add('grid-header');
          cell.innerText = String.fromCharCode(i + 64);
        }
        if (i === 0 && j > 0) {
          // Adds header's row name.
          cell.classList.add('grid-header');
          cell.innerText = j;
        }
        row.appendChild(cell)
      }
    }
}

      const renderGamePlayers = data => {

        var playerOne = document.getElementById('playerOne');
        var playerTwo = document.getElementById('playerTwo');

        if (data.gamePlayers[0].id == gamePlayerId) {
          playerOne.innerText = data.gamePlayers[0].player.email;
          playerTwo.innerText = data.gamePlayers[1].player.email;
        } else {
          playerOne.innerText = data.gamePlayers[1].player.email;
          playerTwo.innerText = data.gamePlayers[0].player.email;
        }


      }

function getParameterByName(name) {
    var match = RegExp('[?&]' + name + '=([^&]*)').exec(window.location.search);
    return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
};

function loadData(){
    $.get('/api/game_view/'+getParameterByName('Gp'))
        .done(function(data) {
            let playerInfo;
            console.log(data)
            if(data.gamePlayers[0].id == getParameterByName('Gp'))
                playerInfo = [data.gamePlayers[0].player.email,data.gamePlayers[1].player.email];
            else
                playerInfo = [data.gamePlayers[1].player.email,data.gamePlayers[0].player.email];
                $('#playerInfo').text(playerInfo[0] + '(you) vs ' + playerInfo[1]);
data.ships.forEach(function(shipPiece){
                shipPiece.location.forEach(function(location){
                $('#'+location).addClass('ship-piece');
                })
            });

            renderGamePlayers(data);
        })
        .fail(function( jqXHR, textStatus ) {
          alert( "Failed: " + textStatus );
        });
};

  createGrid(11,"grid-ships","ship");
  createGrid(11, "grid-salvoes", "salvo");

