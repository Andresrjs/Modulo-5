fetch('/api/games')
  .then(function (response) {
    return response.json();
  })
  .then(function (games) {
    console.log(games);
    for (let index = 0; index < games.length; index++) {
      if (games[index].gamePlayers.length == 1) {
        $("#gameList").append('<li>' + 'Game: ' + games[index].id + ' Created ' + new Date(games[index].created).toLocaleString() + ' Player 1 ' + games[index].gamePlayers[0].player.email + ' Player 2 waiting... ' + '</li>');
      } else {
        $("#gameList").append('<li>' + 'Game: ' + games[index].id + ' Created ' + new Date(games[index].created).toLocaleString() + ' Player 1 ' + games[index].gamePlayers[0].player.email + ' Player 2 ' + games[index].gamePlayers[1].player.email + '</li>');
      }
    }
  })
